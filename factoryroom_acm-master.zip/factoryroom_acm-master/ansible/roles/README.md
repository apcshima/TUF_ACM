# shimizu memo

## 11/19進捗
* 単体テスト継続
    * launch_squid_cent7

        `[root@acmsrv01 ansible]# curl --proxy 192.168.79.17:8080 -L 'https://www.google.co.jp/'`
    * launch_apache_cent6
    
        ポート80は占拠されてなさそうなので解除設定削除
    * launch_nginx_cent6

        パスの誤記修正
    * launch_squid_cent6

        パスの誤記修正
        RPMファイルのバージョンが変わっていたのを修正
        限界･･･もう出来ません。今日はあきらめます
        色々RPM落としてインストールしてみたけどだめ
        el6 3.5 非公式パッケージ※だめだめ
        el6 3.1 公式パッケージあり※コンフィグが3.5晩のため再起動失敗

* テスト用Cent6立ち上げ(`shimizu_cent6`)
    * IPアドレスが足りないため`shimizu_cent7`と同じ

## 11/12進捗
* 担当ミドルplaybookからファイヤウォールの設定削除
* 必要なミドルイメージを`/var/lib/jenkins/middle`配下に配置
* `launch_nginx_cent*`のyumの動きを変更(リモートれぽ指定ー>rpm事前ダウンロード)
* 検証用Cent7仮想マシン構築(`初期構築`スナップショットあり)
    * label: shimizu_cent7
    * IPAddress:192.168.79.17/24(疎通確認済み)
    * ID: root
    * Pass: root
    * SELINUX: off
    * firewalld: off

* `git clone http://192.168.79.16/root/factoryroom_acm.git`を/tmp@acmsrv01にて実行
## 検討すべき課題
* 以前Cent6に関してはミドルのバージョン固定で構築と話したがCent7はどうするんだっけ？固定だっけ？今のところ`latest`指定

* `launch_apache_cent6`ではポート80がデフォルトでなぞプロセスに占拠されていた。以下のコードで回避していたがテンプレートでは必要か？
```
  - name: 80番ポート占領プロセス停止
    shell: fuser -k -n tcp 80
```

* そういえば`squid`で動作確認していませんでした。プロセスが立ち上がるところまでは確認済み。プロ棋士サーバってどうやって検証するの？

* いろいろいじっていたら`launch_nginx_cent6`と`launch_nginx_cent7`がまったく同じになりました。

## 11/15進捗
テスト実施
* launch_apache_cent7 … 誤記発見修正済み
* launch_nginx_cent7 … 誤記発見修正済み