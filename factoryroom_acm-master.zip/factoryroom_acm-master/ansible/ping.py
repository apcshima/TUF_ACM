# -*- coding: utf-8 -*-
import subprocess
import sys
import time

start_time = time.time()  # スクリプト開始時間を記録

args = sys.argv  # Jenkinsから渡される引数を使う準備

cmd = 'ping -c 1 ' +  args[1]  # 実行するpingコマンドを作成

ping = subprocess.call(cmd.split())  # pingコマンドを実行

while ping  == 1:
  print(args[1] + ' is down.')  # pingのステータスコードが1(=失敗)ならループ

  execution_time = time.time() - start_time  # スクリプトの経過時間を記録

  ping = subprocess.call(cmd.split())  # pingコマンドを再度実行

  if execution_time > 1200:  # スクリプト経過時間が20分を超えたらやめる
    print("OS customization requires too much time. If several VMs are not being deployed at the same time, please check the status of vSphere.")
    sys.exit(1)  # ステータスコード1で終了し、Jenkinsジョブを失敗させる

else:  # 30分以内に疎通すればスクリプトが正常に終了
  print(args[1] + ' is up!')
