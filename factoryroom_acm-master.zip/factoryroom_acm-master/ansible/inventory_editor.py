# -*- coding: utf-8 -*-
import sys

args = sys.argv  # Jenkinsから渡される引数を使う準備  

x = args[1]  # vCenterのIP
y = args[2]  # VMのIP

with open('ansible/inventory') as f:
  l = f.readlines()  # インベントリファイルの中身を1行ずつリストに格納

l.insert(1, x)  # リスト2行目にvCenterのIPを挿入
l.insert(5, y)  # リスト6行目にVMのIPを挿入

with open('ansible/inventory', mode='w') as f:
  f.writelines(l)  # 要素追加後のリストをインベントリファイルに上書き

with open('ansible/inventory') as f:
  print(f.read())  # 上書きされたインベントリファイルの中身を表示

