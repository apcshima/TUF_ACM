# -*- coding: utf-8 -*-
import subprocess
import sys

args = sys.argv  # Jenkinsから受け取る引数を使う準備

cmd1 = 'ping -c 5 ' +  args[1]
cmd2 = 'ip neigh show ' + args[1]  # 実行するpingコマンドとarpコマンドを作成

ping = subprocess.call(cmd1.split())
arp = subprocess.Popen(cmd2.split(), stdout=subprocess.PIPE, stderr=subprocess.STDOUT)  # pingとarpを実行

line = arp.stdout.readline()  # arpコマンドの標準出力を代入
res = line.split(' ')  # 標準出力をスペースで区切ってリストに代入

if res[-1] == "FAILED\n":
  print("ok, you can use this IP address!")  # リストの最後がFAILEDならIP重複していないと判定（\nが入るのはイケてない）

else:
  print("IP address duplication!!")  # FAILED以外はIPが使われていると判定
  sys.exit(1)  #スクリプトをステータスコード1で終了しJenkinsのビルドを失敗させる